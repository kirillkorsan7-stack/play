extends Node3D

# Block World 3D — расширенный мобильный прототип для Godot 4.
const WORLD_RADIUS := 13
const BLOCK_SIZE := 1.0
const REACH := 6.0
const SAVE_PATH := "user://block_world_save.json"
const HOTBAR_SIZE := 9
const WALK_SPEED := 5.2
const JUMP_SPEED := 7.0
const GRAVITY := 20.0

const BLOCK_NAMES := [
	"Трава", "Земля", "Камень", "Песок", "Дерево", "Листва",
	"Доски", "Кирпич", "Стекло", "Снег", "Булыжник", "Золотой блок", "Медная руда", "Кристалл"
]
const BLOCK_KEYS := [
	"grass", "dirt", "stone", "sand", "wood", "leaves",
	"planks", "brick", "glass", "snow", "cobble", "gold", "copper", "crystal"
]
const BLOCK_COLORS := [
	Color("#4f9b37"), Color("#805331"), Color("#858b91"), Color("#d8c27b"),
	Color("#754321"), Color("#27733a"), Color("#b47a43"), Color("#a84d3e"),
	Color("#a9dce8"), Color("#e7f2f5"), Color("#626970"), Color("#e7b52e"), Color("#b86b3d"), Color("#62e5dc")
]

var blocks: Dictionary = {} # Vector3i -> {node, kind}
var materials: Dictionary = {}
var height_map: Dictionary = {}
var inventory: Array[int] = [40, 40, 30, 20, 20, 20, 20, 20, 20, 20, 20, 10, 0, 0]
var selected_slot := 0
var hotbar_page := 0

var player: CharacterBody3D
var camera: Camera3D
var sun: DirectionalLight3D
var environment: WorldEnvironment
var world_time := 0.28 # 0..1, около 0.28 — утро

var move_touch_id := -1
var look_touch_id := -1
var move_origin := Vector2.ZERO
var move_vector := Vector2.ZERO
var look_last := Vector2.ZERO
var yaw := 0.0
var pitch := -0.12
var jump_requested := false

var ui_root: Control
var hotbar_buttons: Array[Button] = []
var inventory_label: Label
var status_label: Label
var animals: Array[Dictionary] = []
var monsters: Array[Dictionary] = []
var chunk_roots: Dictionary = {}
var player_health := 100.0
var monster_hit_cooldown := 0.0
var quality_high := true
var water_mesh: MeshInstance3D
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.randomize()
	_create_materials()
	_create_lighting()
	_create_water()
	_generate_world()
	_create_player()
	_create_animals()
	_create_monsters()
	_create_ui()
	_setup_input()
	_update_hotbar()
	_update_inventory_label()

func _create_materials() -> void:
	for i in range(BLOCK_KEYS.size()):
		var mat := StandardMaterial3D.new()
		mat.albedo_color = BLOCK_COLORS[i]
		mat.roughness = 0.9
		if BLOCK_KEYS[i] == "glass":
			mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			mat.albedo_color.a = 0.42
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
		materials[BLOCK_KEYS[i]] = mat

func _create_water() -> void:
	water_mesh = MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(64, 64)
	water_mesh.mesh = plane
	water_mesh.position.y = -0.35
	var water_mat := StandardMaterial3D.new()
	water_mat.albedo_color = Color(0.12, 0.48, 0.72, 0.72)
	water_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	water_mat.roughness = 0.22
	water_mat.metallic = 0.08
	water_mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	water_mesh.material_override = water_mat
	add_child(water_mesh)

func _create_monsters() -> void:
	for i in range(3):
		var monster := Node3D.new()
		monster.name = "Slime_%d" % i
		var body := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 0.48
		sphere.height = 0.82
		body.mesh = sphere
		var mat := StandardMaterial3D.new()
		mat.albedo_color = [Color("#8bd34a"), Color("#b16be0"), Color("#e4a64d")][i]
		mat.roughness = 0.55
		body.material_override = mat
		body.position.y = 0.45
		monster.add_child(body)
		var x := [-9.0, 9.0, 0.0][i]
		var z := [4.0, -3.0, -10.0][i]
		monster.position = Vector3(x, float(height_map.get(Vector2i(roundi(x), roundi(z)), 1)) + 0.05, z)
		add_child(monster)
		monsters.append({"node": monster, "speed": 1.15 + float(i) * 0.15, "phase": float(i)})

func _update_monsters(delta: float) -> void:
	for data in monsters:
		var node: Node3D = data["node"]
		var to_player := player.position - node.position
		to_player.y = 0.0
		if to_player.length() < 11.0 and to_player.length() > 1.15:
			var dir := to_player.normalized()
			node.position += dir * float(data["speed"]) * delta
			node.rotation.y = atan2(dir.x, dir.z)
		elif to_player.length() <= 1.15 and monster_hit_cooldown <= 0.0:
			player_health = maxf(0.0, player_health - 8.0)
			monster_hit_cooldown = 1.0
			if player_health <= 0.0:
				player_health = 100.0
				player.position = Vector3(0, 5.5, 5)
				_set_message("Монстры поймали тебя. Возвращение на базу!")
		var h := float(height_map.get(Vector2i(roundi(node.position.x), roundi(node.position.z)), 1))
		node.position.y = lerpf(node.position.y, h, delta * 5.0)

func _craft_selected() -> void:
	# Рецепт зависит от выбранного слота: доски, кирпич или стекло.
	match selected_slot:
		6:
			if inventory[4] >= 2:
				inventory[4] -= 2
				inventory[6] += 4
				_set_message("Крафт: 2 дерева → 4 доски")
			else:
				_set_message("Нужно 2 блока дерева")
		7:
			if inventory[2] >= 3:
				inventory[2] -= 3
				inventory[7] += 2
				_set_message("Крафт: 3 камня → 2 кирпича")
			else:
				_set_message("Нужно 3 блока камня")
		8:
			if inventory[3] >= 3:
				inventory[3] -= 3
				inventory[8] += 1
				_set_message("Крафт: 3 песка → 1 стекло")
			else:
				_set_message("Нужно 3 блока песка")
		12:
			if inventory[12] >= 3:
				inventory[12] -= 3
				inventory[13] += 1
				_set_message("Крафт: 3 медной руды → кристалл")
			else:
				_set_message("Нужно 3 медной руды")
		_:
			_set_message("Выбери доски, кирпич, стекло или кристалл")
	_update_hotbar()
	_update_inventory_label()

func _toggle_quality() -> void:
	quality_high = not quality_high
	sun.shadow_enabled = quality_high
	sun.directional_shadow_max_distance = 35.0 if quality_high else 15.0
	var env := environment.environment
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC if quality_high else Environment.TONE_MAPPER_LINEAR
	_set_message("Графика: %s" % ("красивая" if quality_high else "экономная"))

func _spawn_break_effect(world_position: Vector3) -> void:
	var burst := CPUParticles3D.new()
	burst.position = world_position
	burst.amount = 10
	burst.lifetime = 0.35
	burst.one_shot = true
	burst.explosiveness = 1.0
	burst.direction = Vector3.UP
	burst.spread = 180.0
	burst.gravity = Vector3(0, -8, 0)
	burst.initial_velocity_min = 1.2
	burst.initial_velocity_max = 3.0
	burst.scale_amount_min = 0.06
	burst.scale_amount_max = 0.14
	add_child(burst)
	burst.emitting = true
	get_tree().create_timer(0.6).timeout.connect(burst.queue_free)

func _create_lighting() -> void:
	environment = WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("#2875b8")
	sky_mat.sky_horizon_color = Color("#a9d7ef")
	sky_mat.ground_bottom_color = Color("#273b25")
	sky_mat.ground_horizon_color = Color("#8caa91")
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#b8d1e8")
	env.ambient_light_energy = 0.65
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.environment = env
	add_child(environment)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_color = Color("#fff0d2")
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	add_child(sun)

func _generate_world() -> void:
	# Небольшой остров с плавными холмами и песчаным берегом.
	for x in range(-WORLD_RADIUS, WORLD_RADIUS + 1):
		for z in range(-WORLD_RADIUS, WORLD_RADIUS + 1):
			var distance := Vector2(x, z).length()
			if distance > WORLD_RADIUS:
				continue
			var wave := sin(float(x) * 0.42) * 0.65 + cos(float(z) * 0.37) * 0.55
			var hill := maxf(0.0, 1.0 - distance / float(WORLD_RADIUS)) * 2.2
			var top_y := int(round(1.0 + wave + hill))
			height_map[Vector2i(x, z)] = top_y
			var top_kind := "grass"
			if distance > WORLD_RADIUS - 2.5:
				top_kind = "sand"
			elif top_y >= 3:
				top_kind = "grass"
			_add_block(Vector3i(x, -3, z), "cobble")
			var underground_kind := "stone"
			if (abs(x * 17 + z * 31) % 37) == 0:
				underground_kind = "copper"
			elif (abs(x * 13 - z * 19) % 71) == 0:
				underground_kind = "crystal"
			_add_block(Vector3i(x, -2, z), underground_kind)
			_add_block(Vector3i(x, -1, z), "dirt")
			for y in range(0, top_y):
				_add_block(Vector3i(x, y, z), "dirt")
			_add_block(Vector3i(x, top_y, z), top_kind)

	# Каменная площадка в центре.
	for x in range(-2, 3):
		for z in range(-2, 3):
			var h := int(height_map.get(Vector2i(x, z), 1))
			_remove_block(Vector3i(x, h, z))
			_add_block(Vector3i(x, h, z), "cobble")

	# Деревья.
	var tree_positions := [Vector2i(-8, -6), Vector2i(7, -7), Vector2i(8, 6), Vector2i(-7, 7), Vector2i(1, -9)]
	for p in tree_positions:
		var ground := int(height_map.get(p, 1))
		for y in range(1, 4):
			_add_block(Vector3i(p.x, ground + y, p.y), "wood")
		for dx in range(-2, 3):
			for dz in range(-2, 3):
				for dy in range(2, 5):
					if abs(dx) + abs(dz) + abs(dy - 3) <= 4:
						_add_block(Vector3i(p.x + dx, ground + dy, p.y + dz), "leaves")

	# Небольшая входная пещера в восточной части острова.
	for x in range(7, 13):
		for y in range(0, 3):
			_remove_block(Vector3i(x, y, 0))

func _add_block(cell: Vector3i, kind: String) -> void:
	if blocks.has(cell):
		return
	if not materials.has(kind):
		kind = "grass"
	var body := StaticBody3D.new()
	body.position = Vector3(cell) * BLOCK_SIZE
	body.name = "Block_%d_%d_%d" % [cell.x, cell.y, cell.z]
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3.ONE * BLOCK_SIZE
	mesh_instance.mesh = mesh
	mesh_instance.material_override = materials[kind]
	body.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3.ONE * BLOCK_SIZE
	collision.shape = shape
	body.add_child(collision)
	var chunk_key := Vector2i(floori(float(cell.x) / 8.0), floori(float(cell.z) / 8.0))
	if not chunk_roots.has(chunk_key):
		var chunk := Node3D.new()
		chunk.name = "Chunk_%d_%d" % [chunk_key.x, chunk_key.y]
		add_child(chunk)
		chunk_roots[chunk_key] = chunk
	chunk_roots[chunk_key].add_child(body)
	blocks[cell] = {"node": body, "kind": kind}

func _remove_block(cell: Vector3i) -> void:
	if not blocks.has(cell):
		return
	var data: Dictionary = blocks[cell]
	if is_instance_valid(data["node"]):
		data["node"].queue_free()
	blocks.erase(cell)

func _create_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, 5.5, 5)
	add_child(player)
	var collider := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.34
	capsule.height = 1.8
	collider.shape = capsule
	collider.position.y = 0.9
	player.add_child(collider)
	camera = Camera3D.new()
	camera.position.y = 1.62
	camera.current = true
	player.add_child(camera)
	player.rotation.y = yaw
	camera.rotation.x = pitch

func _create_animals() -> void:
	for i in range(5):
		var animal := Node3D.new()
		animal.name = "Wanderer_%d" % i
		var body_mesh := MeshInstance3D.new()
		var capsule := CapsuleMesh.new()
		capsule.radius = 0.32
		capsule.height = 0.75
		body_mesh.mesh = capsule
		var mat := StandardMaterial3D.new()
		mat.albedo_color = [Color("#f0eee2"), Color("#a8794f"), Color("#d8c9a5")][i % 3]
		body_mesh.material_override = mat
		animal.add_child(body_mesh)
		var x := rng.randf_range(-7.0, 7.0)
		var z := rng.randf_range(-7.0, 7.0)
		var ground := float(height_map.get(Vector2i(roundi(x), roundi(z)), 1))
		animal.position = Vector3(x, ground + 0.9, z)
		add_child(animal)
		animals.append({
			"node": animal,
			"direction": Vector3(rng.randf_range(-1, 1), 0, rng.randf_range(-1, 1)).normalized(),
			"timer": rng.randf_range(1.0, 4.0),
			"speed": rng.randf_range(0.5, 1.0)
		})

func _create_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui_root = Control.new()
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(ui_root)

	var title := Label.new()
	title.text = "BLOCK WORLD 3D"
	title.position = Vector2(18, 12)
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Color.WHITE)
	ui_root.add_child(title)

	status_label = Label.new()
	status_label.position = Vector2(18, 43)
	status_label.add_theme_font_size_override("font_size", 15)
	status_label.add_theme_color_override("font_color", Color("#f1f5ff"))
	ui_root.add_child(status_label)

	inventory_label = Label.new()
	inventory_label.position = Vector2(18, 68)
	inventory_label.add_theme_font_size_override("font_size", 15)
	inventory_label.add_theme_color_override("font_color", Color("#fff0c2"))
	ui_root.add_child(inventory_label)

	var craft_button := _make_button("КРАФТ", Vector2(-320, -220), Vector2(142, 48))
	craft_button.pressed.connect(_craft_selected)
	var quality_button := _make_button("ГРАФИКА", Vector2(-320, -164), Vector2(142, 48))
	quality_button.pressed.connect(_toggle_quality)
	var break_button := _make_button("СЛОМАТЬ", Vector2(-166, -220), Vector2(148, 52))
	break_button.pressed.connect(_break_block)
	var place_button := _make_button("ПОСТАВИТЬ", Vector2(-166, -160), Vector2(148, 52))
	place_button.pressed.connect(_place_block)
	var jump_button := _make_button("ПРЫЖОК", Vector2(-166, -100), Vector2(148, 52))
	jump_button.pressed.connect(func(): jump_requested = true)
	var save_button := _make_button("СОХРАНИТЬ", Vector2(18, -62), Vector2(132, 44))
	save_button.pressed.connect(_save_world)
	var load_button := _make_button("ЗАГРУЗИТЬ", Vector2(158, -62), Vector2(132, 44))
	load_button.pressed.connect(_load_world)

	# Девять ячеек быстрого доступа.
	for i in range(HOTBAR_SIZE):
		var b := Button.new()
		b.text = str(i + 1)
		b.custom_minimum_size = Vector2(48, 48)
		b.size = Vector2(48, 48)
		b.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
		b.position = Vector2(18 + i * 54, -58)
		b.add_theme_font_size_override("font_size", 16)
		b.pressed.connect(_select_slot.bind(i))
		ui_root.add_child(b)
		hotbar_buttons.append(b)
	var page_button := Button.new()
	page_button.text = "›"
	page_button.custom_minimum_size = Vector2(44, 48)
	page_button.size = Vector2(44, 48)
	page_button.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	page_button.position = Vector2(504, -58)
	page_button.pressed.connect(_next_hotbar_page)
	ui_root.add_child(page_button)

	var help := Label.new()
	help.text = "Слева снизу — ходьба • Справа — поворот камеры"
	help.position = Vector2(18, 104)
	help.add_theme_font_size_override("font_size", 13)
	help.add_theme_color_override("font_color", Color("#e1e9f0"))
	ui_root.add_child(help)

func _make_button(caption: String, bottom_right_offset: Vector2, button_size: Vector2) -> Button:
	var button := Button.new()
	button.text = caption
	button.size = button_size
	button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	button.position = bottom_right_offset
	button.add_theme_font_size_override("font_size", 17)
	button.add_theme_color_override("font_color", Color.WHITE)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.08, 0.19, 0.27, 0.9)
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	style.border_width_left = 2
	style.border_width_top = 2
	style.border_width_right = 2
	style.border_width_bottom = 2
	style.border_color = Color("#8fc4d7")
	button.add_theme_stylebox_override("normal", style)
	ui_root.add_child(button)
	return button

func _setup_input() -> void:
	_add_key_action("move_forward", KEY_W)
	_add_key_action("move_back", KEY_S)
	_add_key_action("move_left", KEY_A)
	_add_key_action("move_right", KEY_D)
	_add_key_action("jump", KEY_SPACE)

func _add_key_action(action: String, key: int) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var event := InputEventKey.new()
	event.physical_keycode = key
	InputMap.action_add_event(action, event)

func _process(delta: float) -> void:
	world_time = fposmod(world_time + delta / 420.0, 1.0)
	var angle := world_time * TAU
	sun.rotation_degrees = Vector3(-35.0 - sin(angle) * 55.0, -35.0, 0.0)
	sun.light_energy = clampf(0.25 + maxf(0.0, sin(angle)) * 1.15, 0.12, 1.4)
	if environment.environment.sky.sky_material is ProceduralSkyMaterial:
		var sky_mat := environment.environment.sky.sky_material as ProceduralSkyMaterial
		var daylight := clampf(0.25 + maxf(0.0, sin(angle)) * 0.85, 0.25, 1.0)
		sky_mat.sky_top_color = Color("#14243f").lerp(Color("#2875b8"), daylight)
		sky_mat.sky_horizon_color = Color("#34415c").lerp(Color("#a9d7ef"), daylight)
	status_label.text = "Время: %02d:%02d   ♥ %d" % [int(world_time * 24.0), int(fposmod(world_time * 1440.0, 60.0)), int(player_health)]

	_update_animals(delta)
	_update_monsters(delta)	
	monster_hit_cooldown = maxf(0.0, monster_hit_cooldown - delta)

func _physics_process(delta: float) -> void:
	var input_dir := Vector2.ZERO
	if move_touch_id != -1:
		input_dir = move_vector
	else:
		input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var forward := -player.global_transform.basis.z
	var right := player.global_transform.basis.x
	var direction := (right * input_dir.x + forward * -input_dir.y).normalized()
	var swimming := player.position.y < 0.55
	var move_speed := WALK_SPEED * (0.62 if swimming else 1.0)
	player.velocity.x = direction.x * move_speed
	player.velocity.z = direction.z * move_speed
	if swimming:
		player.velocity.y = lerpf(player.velocity.y, 1.2 if jump_requested else -0.25, delta * 2.0)
	elif not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	elif jump_requested or Input.is_action_just_pressed("jump"):
		player.velocity.y = JUMP_SPEED
	jump_requested = false
	player.move_and_slide()

func _update_animals(delta: float) -> void:
	for animal_data in animals:
		var node: Node3D = animal_data["node"]
		animal_data["timer"] = float(animal_data["timer"]) - delta
		if float(animal_data["timer"]) <= 0.0:
			animal_data["timer"] = rng.randf_range(1.5, 5.0)
			animal_data["direction"] = Vector3(rng.randf_range(-1, 1), 0, rng.randf_range(-1, 1)).normalized()
		var direction: Vector3 = animal_data["direction"]
		var next_pos := node.position + direction * float(animal_data["speed"]) * delta
		if Vector2(next_pos.x, next_pos.z).length() > WORLD_RADIUS - 2:
			animal_data["direction"] = -direction
		else:
			node.position.x = next_pos.x
			node.position.z = next_pos.z
			var h := int(height_map.get(Vector2i(roundi(node.position.x), roundi(node.position.z)), 1))
			node.position.y = lerpf(node.position.y, float(h) + 0.9, delta * 5.0)
			if direction.length() > 0.1:
				node.rotation.y = atan2(direction.x, direction.z)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			var width := get_viewport().get_visible_rect().size.x
			var height := get_viewport().get_visible_rect().size.y
			if event.position.x < width * 0.45 and event.position.y > height * 0.45:
				move_touch_id = event.index
				move_origin = event.position
				move_vector = Vector2.ZERO
			elif event.position.x >= width * 0.45:
				look_touch_id = event.index
				look_last = event.position
		else:
			if event.index == move_touch_id:
				move_touch_id = -1
				move_vector = Vector2.ZERO
			if event.index == look_touch_id:
				look_touch_id = -1
	elif event is InputEventScreenDrag:
		if event.index == move_touch_id:
			var delta := event.position - move_origin
			move_vector = Vector2(clampf(delta.x / 72.0, -1.0, 1.0), clampf(delta.y / 72.0, -1.0, 1.0))
		elif event.index == look_touch_id:
			var delta := event.position - look_last
			yaw -= delta.x * 0.004
			pitch = clampf(pitch - delta.y * 0.004, -1.3, 1.3)
			player.rotation.y = yaw
			camera.rotation.x = pitch
			look_last = event.position

func _target_block() -> Dictionary:
	var from := camera.global_position
	var to := from + (-camera.global_transform.basis.z) * REACH
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [player.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return {}
	var collider = hit.get("collider")
	if collider == null or not collider is StaticBody3D:
		return {}
	var cell := Vector3i(roundi(collider.position.x), roundi(collider.position.y), roundi(collider.position.z))
	if not blocks.has(cell):
		return {}
	return {"cell": cell, "normal": hit.get("normal", Vector3.UP)}

func _break_block() -> void:
	var target := _target_block()
	if target.is_empty():
		_set_message("Наведи прицел на блок")
		return
	var cell: Vector3i = target["cell"]
	if cell.y <= -3:
		_set_message("Основание острова слишком прочное")
		return
	var kind: String = blocks[cell]["kind"]
	_remove_block(cell)
	var index := BLOCK_KEYS.find(kind)
	if index >= 0:
		inventory[index] += 1
	_spawn_break_effect(Vector3(cell))
	_update_inventory_label()
	_update_hotbar()

func _place_block() -> void:
	var target := _target_block()
	if target.is_empty():
		_set_message("Наведи прицел на блок")
		return
	var cell: Vector3i = target["cell"]
	var normal: Vector3 = target["normal"]
	var offset := Vector3i(roundi(normal.x), roundi(normal.y), roundi(normal.z))
	var new_cell := cell + offset
	if blocks.has(new_cell):
		return
	if inventory[selected_slot] <= 0:
		_set_message("В этой ячейке закончились блоки")
		return
	var player_box := player.position + Vector3(0, 0.8, 0)
	if Vector3(new_cell).distance_to(player_box) < 1.25:
		_set_message("Нельзя поставить блок внутри игрока")
		return
	_add_block(new_cell, BLOCK_KEYS[selected_slot])
	inventory[selected_slot] -= 1
	_update_inventory_label()
	_update_hotbar()

func _select_slot(index: int) -> void:
	selected_slot = (index + hotbar_page * HOTBAR_SIZE) % BLOCK_KEYS.size()
	_update_hotbar()
	_update_inventory_label()

func _next_hotbar_page() -> void:
	hotbar_page = (hotbar_page + 1) % 2
	_update_hotbar()
	_update_inventory_label()

func _update_hotbar() -> void:
	for i in range(hotbar_buttons.size()):
		var key_index := (i + hotbar_page * HOTBAR_SIZE) % BLOCK_KEYS.size()
		var prefix := "▶ " if key_index == selected_slot else ""
		hotbar_buttons[i].text = "%s%d\n%s" % [prefix, inventory[key_index], BLOCK_NAMES[key_index]]
		hotbar_buttons[i].tooltip_text = BLOCK_NAMES[key_index]

func _update_inventory_label() -> void:
	inventory_label.text = "Выбрано: %s × %d" % [BLOCK_NAMES[selected_slot], inventory[selected_slot]]

func _set_message(message: String) -> void:
	inventory_label.text = message

func _save_world() -> void:
	var data := {
		"blocks": [],
		"inventory": inventory,
		"selected_slot": selected_slot,
		"player_position": [player.position.x, player.position.y, player.position.z],
		"world_time": world_time
	}
	for cell in blocks.keys():
		data["blocks"].append({
			"x": cell.x, "y": cell.y, "z": cell.z,
			"kind": blocks[cell]["kind"]
		})
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		_set_message("Ошибка сохранения")
		return
	file.store_string(JSON.stringify(data))
	file.close()
	_set_message("Мир сохранён!")

func _load_world() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		_set_message("Сохранение пока не найдено")
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		_set_message("Не удалось открыть сохранение")
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY or not parsed.has("blocks"):
		_set_message("Файл сохранения повреждён")
		return
	for cell in blocks.keys():
		var old_data: Dictionary = blocks[cell]
		if is_instance_valid(old_data["node"]):
			old_data["node"].queue_free()
	blocks.clear()
	for item in parsed["blocks"]:
		var cell := Vector3i(int(item["x"]), int(item["y"]), int(item["z"]))
		_add_block(cell, str(item["kind"]))
	if parsed.has("inventory"):
		var saved_inventory: Array = parsed["inventory"]
		for i in range(mini(inventory.size(), saved_inventory.size())):
			inventory[i] = int(saved_inventory[i])
	selected_slot = clampi(int(parsed.get("selected_slot", 0)), 0, BLOCK_KEYS.size() - 1)
	hotbar_page = 1 if selected_slot >= HOTBAR_SIZE else 0
	world_time = float(parsed.get("world_time", world_time))
	if parsed.has("player_position"):
		var pos: Array = parsed["player_position"]
		if pos.size() == 3:
			player.position = Vector3(float(pos[0]), float(pos[1]), float(pos[2]))
	_update_hotbar()
	_update_inventory_label()
	_set_message("Мир загружен!")
